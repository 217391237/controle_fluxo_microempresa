package dao;

import model.*;
import java.sql.*;
import java.time.LocalDateTime;

public class VendaDAO {
    
    public void inserir(Venda venda) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            
            try {
                // Inserir venda
                String sqlVenda = "INSERT INTO vendas (cliente_id, data_venda, forma_pagamento_id, valor_total) VALUES (?, ?, ?, ?)";
                
                try (PreparedStatement stmtVenda = conn.prepareStatement(sqlVenda, Statement.RETURN_GENERATED_KEYS)) {
                    stmtVenda.setInt(1, venda.getCliente().getId());
                    stmtVenda.setTimestamp(2, Timestamp.valueOf(venda.getDataVenda()));
                    stmtVenda.setInt(3, venda.getFormaPagamento().getId());
                    stmtVenda.setBigDecimal(4, venda.getValorTotal());
                    
                    stmtVenda.executeUpdate();
                    
                    try (ResultSet rs = stmtVenda.getGeneratedKeys()) {
                        if (rs.next()) {
                            venda.setId(rs.getInt(1));
                        }
                    }
                }
                
                // Inserir itens da venda
                String sqlItem = "INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario) VALUES (?, ?, ?, ?)";
                
                try (PreparedStatement stmtItem = conn.prepareStatement(sqlItem)) {
                    for (ItemVenda item : venda.getItens()) {
                        stmtItem.setInt(1, venda.getId());
                        stmtItem.setInt(2, item.getProduto().getId());
                        stmtItem.setInt(3, item.getQuantidade());
                        stmtItem.setBigDecimal(4, item.getPrecoUnitario());
                        stmtItem.addBatch();
                    }
                    stmtItem.executeBatch();
                }
                
                String sqlEstoque = "UPDATE produtos SET estoque = estoque - ? WHERE id = ?";
                try (PreparedStatement stmtEstoque = conn.prepareStatement(sqlEstoque)) {
                    for (ItemVenda item : venda.getItens()) {
                        stmtEstoque.setInt(1, item.getQuantidade());
                        stmtEstoque.setInt(2, item.getProduto().getId());
                        stmtEstoque.addBatch();
                    }
                    stmtEstoque.executeBatch();
                }
                
                conn.commit();
                
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }
}
