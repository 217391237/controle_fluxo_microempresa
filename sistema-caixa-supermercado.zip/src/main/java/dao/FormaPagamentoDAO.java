package dao;

import model.FormaPagamento;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormaPagamentoDAO {
    
    public List<FormaPagamento> listarTodas() throws SQLException {
        List<FormaPagamento> formas = new ArrayList<>();
        String sql = "SELECT * FROM formas_pagamento ORDER BY tipo";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                formas.add(new FormaPagamento(
                    rs.getInt("id"),
                    rs.getString("tipo")
                ));
            }
        }
        return formas;
    }
    
    public FormaPagamento buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM formas_pagamento WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new FormaPagamento(
                        rs.getInt("id"),
                        rs.getString("tipo")
                    );
                }
            }
        }
        return null;
    }
}
