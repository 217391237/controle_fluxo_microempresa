package service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import model.*;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;

public class NotaFiscalService {
    
    public void gerarNotaFiscal(Venda venda, String caminhoArquivo) throws DocumentException, IOException {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(caminhoArquivo));
        
        document.open();
        
        // Título
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18, BaseColor.BLACK);
        Paragraph title = new Paragraph("NOTA FISCAL", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);
        
        document.add(new Paragraph(" "));
        
        // Informações da empresa
        Font boldFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.BLACK);
        Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 10, BaseColor.BLACK);
        
        document.add(new Paragraph("VM Software Supermercado", boldFont));
        document.add(new Paragraph("CNPJ: 12.345.678/0001-90", normalFont));
        document.add(new Paragraph("Endereço: Rua das Flores, 123 - Centro", normalFont));
        document.add(new Paragraph(" "));
        
        // Dados da venda
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        document.add(new Paragraph("Nota Fiscal Nº: " + venda.getId(), boldFont));
        document.add(new Paragraph("Data: " + venda.getDataVenda().format(formatter), normalFont));
        document.add(new Paragraph(" "));
        
        // Dados do cliente
        document.add(new Paragraph("DADOS DO CLIENTE", boldFont));
        document.add(new Paragraph("Nome: " + venda.getCliente().getNome(), normalFont));
        document.add(new Paragraph("CPF: " + venda.getCliente().getCpf(), normalFont));
        document.add(new Paragraph("Contato: " + venda.getCliente().getContato(), normalFont));
        document.add(new Paragraph(" "));
        
        // Tabela de produtos
        document.add(new Paragraph("PRODUTOS", boldFont));
        
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{3, 1, 2, 2, 2});
        
        // Cabeçalho da tabela
        PdfPCell header1 = new PdfPCell(new Phrase("Produto", boldFont));
        PdfPCell header2 = new PdfPCell(new Phrase("Qtd", boldFont));
        PdfPCell header3 = new PdfPCell(new Phrase("Valor Unit.", boldFont));
        PdfPCell header4 = new PdfPCell(new Phrase("Subtotal", boldFont));
        
        header1.setHorizontalAlignment(Element.ALIGN_CENTER);
        header2.setHorizontalAlignment(Element.ALIGN_CENTER);
        header3.setHorizontalAlignment(Element.ALIGN_CENTER);
        header4.setHorizontalAlignment(Element.ALIGN_CENTER);
        
        table.addCell(header1);
        table.addCell(header2);
        table.addCell(header3);
        table.addCell(header4);
        
        // Itens da venda
        for (ItemVenda item : venda.getItens()) {
            table.addCell(new PdfPCell(new Phrase(item.getProduto().getNome(), normalFont)));
            table.addCell(new PdfPCell(new Phrase(String.valueOf(item.getQuantidade()), normalFont)));
            table.addCell(new PdfPCell(new Phrase("R$ " + item.getPrecoUnitario().toString(), normalFont)));
            table.addCell(new PdfPCell(new Phrase("R$ " + item.getSubtotal().toString(), normalFont)));
        }
        
        document.add(table);
        document.add(new Paragraph(" "));
        
        // Total e forma de pagamento
        document.add(new Paragraph("TOTAL: R$ " + venda.getValorTotal().toString(), boldFont));
        document.add(new Paragraph("Forma de Pagamento: " + venda.getFormaPagamento().getTipo(), normalFont));
        document.add(new Paragraph(" "));
        
        document.add(new Paragraph("Obrigado pela preferência!", normalFont));
        
        document.close();
    }
}
