import view.CaixaSupermercadoFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                // Definir look and feel do sistema
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeel());
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            // Criar e exibir a interface
            new CaixaSupermercadoFrame().setVisible(true);
        });
    }
}
