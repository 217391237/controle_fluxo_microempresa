package view;

import dao.*;
import model.*;
import service.NotaFiscalService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class CaixaSupermercadoFrame extends JFrame {
    
    // DAOs
    private ClienteDAO clienteDAO;
    private ProdutoDAO produtoDAO;
    private FormaPagamentoDAO formaPagamentoDAO;
    private VendaDAO vendaDAO;
    private NotaFiscalService notaFiscalService;
    
    // Componentes da interface
    private JTextField txtNomeCliente;
    private JTextField txtContatoCliente;
    private JTextField txtCpfCliente;
    private JComboBox<Produto> cbProdutos;
    private JSpinner spnQuantidade;
    private JComboBox<FormaPagamento> cbFormaPagamento;
    private JTable tblItens;
    private DefaultTableModel modeloTabela;
    private JLabel lblTotal;
    
    // Venda atual
    private Venda vendaAtual;
    
    public CaixaSupermercadoFrame() {
        initializeDAOs();
        initializeComponents();
        setupLayout();
        loadData();
        novaVenda();
    }
    
    private void initializeDAOs() {
        clienteDAO = new ClienteDAO();
        produtoDAO = new ProdutoDAO();
        formaPagamentoDAO = new FormaPagamentoDAO();
        vendaDAO = new VendaDAO();
        notaFiscalService = new NotaFiscalService();
    }
    
    private void initializeComponents() {
        setTitle("Sistema de Caixa - VM Software");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        // Campos do cliente
        txtNomeCliente = new JTextField(20);
        txtContatoCliente = new JTextField(15);
        txtCpfCliente = new JTextField(15);
        
        // Seleção de produtos
        cbProdutos = new JComboBox<>();
        spnQuantidade = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        
        // Forma de pagamento
        cbFormaPagamento = new JComboBox<>();
        
        // Tabela de itens
        String[] colunas = {"Produto", "Quantidade", "Valor Unit.", "Subtotal"};
        modeloTabela = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblItens = new JTable(modeloTabela);
        
        // Label do total
        lblTotal = new JLabel("Total: R$ 0,00");
        lblTotal.setFont(new Font("Arial", Font.BOLD, 16));
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Panel principal
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Panel do cliente
        JPanel clientePanel = createClientePanel();
        
        // Panel dos produtos
        JPanel produtoPanel = createProdutoPanel();
        
        // Panel da tabela
        JPanel tabelaPanel = createTabelaPanel();
        
        // Panel do total e pagamento
        JPanel totalPanel = createTotalPanel();
        
        // Panel dos botões
        JPanel botoesPanel = createBotoesPanel();
        
        // Organizando os panels
        JPanel topPanel = new JPanel(new GridLayout(2, 1));
        topPanel.add(clientePanel);
        topPanel.add(produtoPanel);
        
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalPanel, BorderLayout.NORTH);
        bottomPanel.add(botoesPanel, BorderLayout.SOUTH);
        
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tabelaPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createClientePanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(BorderFactory.createTitledBorder("Dados do Cliente"));
        
        panel.add(new JLabel("Nome:"));
        panel.add(txtNomeCliente);
        panel.add(new JLabel("Contato:"));
        panel.add(txtContatoCliente);
        panel.add(new JLabel("CPF:"));
        panel.add(txtCpfCliente);
        
        return panel;
    }
    
    private JPanel createProdutoPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(BorderFactory.createTitledBorder("Adicionar Produto"));
        
        panel.add(new JLabel("Produto:"));
        panel.add(cbProdutos);
        panel.add(new JLabel("Quantidade:"));
        panel.add(spnQuantidade);
        
        JButton btnAdicionar = new JButton("Adicionar");
        btnAdicionar.addActionListener(e -> adicionarProduto());
        panel.add(btnAdicionar);
        
        JButton btnRemover = new JButton("Remover");
        btnRemover.addActionListener(e -> removerProduto());
        panel.add(btnRemover);
        
        return panel;
    }
    
    private JPanel createTabelaPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Itens da Venda"));
        
        JScrollPane scrollPane = new JScrollPane(tblItens);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createTotalPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        panel.add(new JLabel("Forma de Pagamento:"));
        panel.add(cbFormaPagamento);
        panel.add(Box.createHorizontalStrut(20));
        panel.add(lblTotal);
        
        return panel;
    }
    
    private JPanel createBotoesPanel() {
        JPanel panel = new JPanel(new FlowLayout());
        
        JButton btnNovaVenda = new JButton("Nova Venda");
        btnNovaVenda.addActionListener(e -> novaVenda());
        
        JButton btnFinalizarVenda = new JButton("Finalizar Venda");
        btnFinalizarVenda.addActionListener(e -> finalizarVenda());
        
        panel.add(btnNovaVenda);
        panel.add(btnFinalizarVenda);
        
        return panel;
    }
    
    private void loadData() {
        try {
            // Carregar produtos
            List<Produto> produtos = produtoDAO.listarTodos();
            cbProdutos.removeAllItems();
            for (Produto produto : produtos) {
                cbProdutos.addItem(produto);
            }
            
            // Carregar formas de pagamento
            List<FormaPagamento> formas = formaPagamentoDAO.listarTodas();
            cbFormaPagamento.removeAllItems();
            for (FormaPagamento forma : formas) {
                cbFormaPagamento.addItem(forma);
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao carregar dados: " + e.getMessage(), 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void novaVenda() {
        vendaAtual = new Venda();
        
        // Limpar campos
        txtNomeCliente.setText("");
        txtContatoCliente.setText("");
        txtCpfCliente.setText("");
        
        // Limpar tabela
        modeloTabela.setRowCount(0);
        
        // Reset quantidade
        spnQuantidade.setValue(1);
        
        atualizarTotal();
    }
    
    private void adicionarProduto() {
        if (cbProdutos.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecione um produto!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        Produto produto = (Produto) cbProdutos.getSelectedItem();
        int quantidade = (Integer) spnQuantidade.getValue();
        
        // Verificar estoque
        if (quantidade > produto.getEstoque()) {
            JOptionPane.showMessageDialog(this, "Quantidade indisponível em estoque!", 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        ItemVenda item = new ItemVenda(produto, quantidade);
        vendaAtual.adicionarItem(item);
        
        // Adicionar na tabela
        Object[] linha = {
            produto.getNome(),
            quantidade,
            "R$ " + produto.getPreco(),
            "R$ " + item.getSubtotal()
        };
        modeloTabela.addRow(linha);
        
        atualizarTotal();
        spnQuantidade.setValue(1);
    }
    
    private void removerProduto() {
        int selectedRow = tblItens.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um item para remover!", 
                                        "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        vendaAtual.getItens().remove(selectedRow);
        modeloTabela.removeRow(selectedRow);
        atualizarTotal();
    }
    
    private void atualizarTotal() {
        lblTotal.setText("Total: R$ " + vendaAtual.getValorTotal());
    }
    
    private void finalizarVenda() {
        // Validar dados do cliente
        if (txtNomeCliente.getText().trim().isEmpty() || 
            txtCpfCliente.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha os dados do cliente!", 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar itens
        if (vendaAtual.getItens().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Adicione pelo menos um produto!", 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validar forma de pagamento
        if (cbFormaPagamento.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecione a forma de pagamento!", 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        try {
            // Buscar ou criar cliente
            Cliente cliente = clienteDAO.buscarPorCpf(txtCpfCliente.getText().trim());
            if (cliente == null) {
                cliente = new Cliente(
                    txtNomeCliente.getText().trim(),
                    txtContatoCliente.getText().trim(),
                    txtCpfCliente.getText().trim()
                );
                clienteDAO.inserir(cliente);
            }
            
            // Configurar venda
            vendaAtual.setCliente(cliente);
            vendaAtual.setFormaPagamento((FormaPagamento) cbFormaPagamento.getSelectedItem());
            
            // Salvar venda
            vendaDAO.inserir(vendaAtual);
            
            // Gerar nota fiscal
            String caminhoNota = "nota_fiscal_" + vendaAtual.getId() + ".pdf";
            notaFiscalService.gerarNotaFiscal(vendaAtual, caminhoNota);
            
            JOptionPane.showMessageDialog(this, 
                "Venda finalizada com sucesso!\nNota fiscal gerada: " + caminhoNota, 
                "Sucesso", JOptionPane.INFORMATION_MESSAGE);
            
            // Recarregar produtos (estoque atualizado)
            loadData();
            
            // Nova venda
            novaVenda();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erro ao finalizar venda: " + e.getMessage(), 
                                        "Erro", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
