package model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Venda {
    private int id;
    private Cliente cliente;
    private LocalDateTime dataVenda;
    private FormaPagamento formaPagamento;
    private BigDecimal valorTotal;
    private List<ItemVenda> itens;
    
    public Venda() {
        this.itens = new ArrayList<>();
        this.dataVenda = LocalDateTime.now();
        this.valorTotal = BigDecimal.ZERO;
    }
    
    public Venda(Cliente cliente, FormaPagamento formaPagamento) {
        this();
        this.cliente = cliente;
        this.formaPagamento = formaPagamento;
    }
    
    public void adicionarItem(ItemVenda item) {
        this.itens.add(item);
        calcularTotal();
    }
    
    public void removerItem(ItemVenda item) {
        this.itens.remove(item);
        calcularTotal();
    }
    
    private void calcularTotal() {
        this.valorTotal = itens.stream()
                .map(ItemVenda::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    
    public LocalDateTime getDataVenda() { return dataVenda; }
    public void setDataVenda(LocalDateTime dataVenda) { this.dataVenda = dataVenda; }
    
    public FormaPagamento getFormaPagamento() { return formaPagamento; }
    public void setFormaPagamento(FormaPagamento formaPagamento) { this.formaPagamento = formaPagamento; }
    
    public BigDecimal getValorTotal() { return valorTotal; }
    public void setValorTotal(BigDecimal valorTotal) { this.valorTotal = valorTotal; }
    
    public List<ItemVenda> getItens() { return itens; }
    public void setItens(List<ItemVenda> itens) { 
        this.itens = itens;
        calcularTotal();
    }
}
