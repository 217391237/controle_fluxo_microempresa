-- Inserir formas de pagamento
INSERT INTO formas_pagamento (tipo) VALUES 
('Débito'),
('Crédito'),
('Pix'),
('Dinheiro');

-- Inserir produtos de exemplo
INSERT INTO produtos (nome, preco, estoque) VALUES 
('Arroz 5kg', 25.90, 50),
('Feijão 1kg', 8.50, 30),
('Açúcar 1kg', 4.20, 40),
('Óleo de Soja 900ml', 6.80, 25),
('Macarrão 500g', 3.50, 60),
('Leite 1L', 4.90, 35),
('Pão de Açúcar 500g', 5.20, 20),
('Café 500g', 12.90, 15),
('Sabão em Pó 1kg', 8.90, 25),
('Papel Higiênico 4 rolos', 7.50, 40);
